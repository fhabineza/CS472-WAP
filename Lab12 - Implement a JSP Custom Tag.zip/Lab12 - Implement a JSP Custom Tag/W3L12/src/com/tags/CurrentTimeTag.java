package com.tags;

import java.io.IOException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentTimeTag extends SimpleTagSupport {

	private String color;
	private String size;

	public void setColor(String color) {
		this.color = color;
	}

	public void setSize(String size) {
		this.size = size;
	}

	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out = getJspContext().getOut(); 

		 String timex = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("h:mm:ss a zzzz"));

		if (color != null) {
			out.write(String.format("<span style='color:%s; font-size:%s'>%s</span>", color, size, timex));
		} else {
			out.write(String.format("<span>%s</span>", timex));
		}
	}

}
