package com.tags;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class CurrentDateTag extends SimpleTagSupport {

	private String color;
	private String size;

	public void setColor(String color) {
		this.color = color;
	}

	public void setSize(String size) {
		this.size = size;
	}

	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out = getJspContext().getOut();
		LocalDate dNow = LocalDate.now();

		String datex = dNow.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy"));

		if (color != null) {
			out.write(String.format("<span style='color:%s; font-size:%s'>%s</span>", color, size, datex));
		} else {
			out.write(String.format("<span>%s</span>", datex));
		}
	}

}
