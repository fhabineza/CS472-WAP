package edu.mum.wap.model;

public class Data {
	private String name;
	private String gender;
	private String category;
	private String message;

	public Data(String name, String gender, String category, String message) {
		super();
		this.name = name;
		this.gender = gender;
		this.category = category;
		this.message = message;
	}

	public Data() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
