package edu.mum.wap.model;

import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.CodeSource;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class DataIO {

	public static void writeInJSONFile(Data newData, String path) {
		try {

			JSONObject newObject = new JSONObject();
			newObject.put("name", newData.getName());
			newObject.put("gender", newData.getGender());
			newObject.put("category", newData.getCategory());
			newObject.put("message", newData.getMessage()); 

			JSONArray json = readFromJSONFile(path + "\\projectdata\\jsondata.json");
			json.add(newObject);

			Files.write(Paths.get(path + "\\projectdata\\jsondata.json"), json.toJSONString().getBytes());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static JSONArray readFromJSONFile(String filename) {
		JSONArray data = new JSONArray();
		try {
			FileReader reader = new FileReader(filename);
			JSONParser jsonParser = new JSONParser();
			data = (JSONArray) jsonParser.parse(reader);
		} catch (Exception e) {
			// TODO: handle exception
		}
		return data;
	}

}
