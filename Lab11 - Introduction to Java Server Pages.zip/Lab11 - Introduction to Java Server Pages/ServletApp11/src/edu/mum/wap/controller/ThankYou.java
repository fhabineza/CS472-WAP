package edu.mum.wap.controller;

import java.io.IOException;
import java.time.LocalDateTime;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ThankYou
 */
@WebServlet("/ThankYou")
public class ThankYou extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Long hitCounter;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ThankYou() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		hitCounter = Long.valueOf(0);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		hitCounter++;
		String hitCounterText = "<div class=\"row\"> <div class=\"col-md-6\"> <h3 class=\"text-danger\">Hit Counter/Visits: "
				+ hitCounter + "</h3> </div> </div>";

		String date = LocalDateTime.now().toString();
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String category = request.getParameter("category");
		String message = request.getParameter("message");
		String receivedData = "1. Name: " + name + "</br>" + "2. Gender: " + gender + "</br>" + "3. Category: "
				+ category + "</br>" + "4. Message: " + message;
		String thankYouPage = "<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "\r\n" + "<head>\r\n"
				+ "<meta charset=\"UTF-8\">\r\n"
				+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
				+ "<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\r\n" + "<title>Thank You Page</title>\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\"\r\n"
				+ "	integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\"\r\n"
				+ "	crossorigin=\"anonymous\">\r\n" + "<style>\r\n" + "#myheader {\r\n" + "	text-align: center;\r\n"
				+ "	font-size: 30px;\r\n" + "	text-decoration: underline;\r\n" + "	background-color: black;\r\n"
				+ "	color: white;\r\n" + "	border-radius: 10px;\r\n" + "	margin-top: 10px;\r\n"
				+ "	margin-bottom: 20px;\r\n" + "}\r\n" + "</style>\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n"
				+ "\r\n" + "	<nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">\r\n"
				+ "		<a class=\"navbar-brand\" href=\"#\">Lab10 - Introduction to Java\r\n"
				+ "			Servlet technology</a>\r\n"
				+ "		<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n"
				+ "			data-target=\"#navbarColor02\" aria-controls=\"navbarColor02\"\r\n"
				+ "			aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "			<span class=\"navbar-toggler-icon\"></span>\r\n" + "		</button>\r\n" + "\r\n"
				+ "		<div class=\"collapse navbar-collapse\" id=\"navbarColor02\">\r\n"
				+ "			<ul class=\"navbar-nav mr-auto\">\r\n"
				+ "				<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "					href=\"../../index.html\">| Homepage</a></li>\r\n" + "			</ul>\r\n"
				+ "			<form class=\"form-inline\" action=\"../../index.html\">\r\n" + "\r\n"
				+ "				<button class=\"btn btn-outline-light my-2 my-sm-0\" type=\"submit\">Sign\r\n"
				+ "					Out</button>\r\n" + "			</form>\r\n" + "		</div>\r\n" + "	</nav>\r\n"
				+ "\r\n" + "	<div class=\"container\">\r\n" + "		<header id=\"myheader\"> </header>\r\n"
				+ "		<div>\r\n" + "			<h3 style=\"color: green\">Thank you for contacting us!!!</h3>\r\n"
				+ "			<h4>We are pleased to let you know that following data have been\r\n"
				+ "				collected from you </br>@ " + date + ".</h4>\r\n" + "			<h5>" + receivedData
				+ "</h5>\r\n" + "		</div>\r\n" + hitCounterText + "	</div>\r\n" + "</body>\r\n" + "\r\n"
				+ "</html>";
		response.getWriter().append(thankYouPage);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
