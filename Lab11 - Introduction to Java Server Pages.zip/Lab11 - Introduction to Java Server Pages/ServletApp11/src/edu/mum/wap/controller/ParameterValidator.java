package edu.mum.wap.controller;

public class ParameterValidator {

	public static boolean validateInputText(String value) {
		if (value == null || value.isEmpty())
			return false;
		return true;
	}

	public static boolean validateInputRadio(String value) {
		if (value == null || value.isEmpty())
			return false;
		return true;
	}

}
