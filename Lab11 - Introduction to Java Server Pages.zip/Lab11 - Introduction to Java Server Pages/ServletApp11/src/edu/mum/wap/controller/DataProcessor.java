package edu.mum.wap.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.mum.wap.model.Data;
import edu.mum.wap.model.DataIO;

/**
 * Servlet implementation class HelloServlet
 */
@WebServlet(description = "DataProcessor", urlPatterns = { "/DataProcessor" })
public class DataProcessor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DataProcessor() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		System.out.println("\n##################################################\n");
		System.out.println("METHOD INIT IS CALLED");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Hello Java Servlet 4.0.").append(" @ " + request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String errorMessage = "";
		String name = request.getParameter("name");
		if (name.isEmpty()) {
			errorMessage += "Name is empty</br>";
		}
		String gender = request.getParameter("gender");
		if (gender == null || gender.isEmpty()) {
			errorMessage += "Gender is not selected</br>";
		}
		String category = request.getParameter("category");
		if (category.isEmpty() || category.equals("Select Category")) {
			errorMessage += "Category is not selected</br>";
		}
		String message = request.getParameter("message");
		if (message.isEmpty()) {
			errorMessage += "Message is empty</br>";
		}

		if (errorMessage.equals("")) {
			String path = request.getServletContext().getRealPath(".");
			DataIO.writeInJSONFile(new Data(name, gender, category, message), path);
		} else {
			request.setAttribute("errorMessage", errorMessage);
		}

		RequestDispatcher view = request.getRequestDispatcher("/ContactUs");
		view.forward(request, response);
//		
//		if (errorMessage.equals("")) {
//			response.sendRedirect("/ServletApp11/ThankYou?name=" + name + "&gender=" + gender + "&category=" + category
//					+ "&message=" + message);
//		} else {
//			request.setAttribute("errorMessage", errorMessage);
//			RequestDispatcher view = request.getRequestDispatcher("/ContactUs");
//			view.forward(request, response);
//		}

	}

}
