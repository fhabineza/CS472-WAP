package edu.mum.wap.controller;

import java.io.IOException;
import java.nio.file.Paths;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import edu.mum.wap.model.DataIO;

/**
 * Servlet implementation class ContactUs
 */
@WebServlet(description = "/ContactUs", urlPatterns = { "/ContactUs" })
public class ContactUs extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Long hitCounter;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ContactUs() {
		super();
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		hitCounter = Long.valueOf(0);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String path = request.getServletContext().getRealPath(".");
		JSONArray json = DataIO.readFromJSONFile(path + "\\projectdata\\jsondata.json");

		String name = request.getParameter("name");
		if (name == null || name.isEmpty())
			name = "";
		String gender = request.getParameter("gender");
		String category = request.getParameter("category");
		if (category == null || category.isEmpty())
			category = "Select Category";
		String message = request.getParameter("message");
		if (message == null || message.isEmpty())
			message = "";

		String dataRows = "";
		for (int i = 0; i < json.size(); i++) {
			JSONObject newObject = (JSONObject) json.get(i);
			dataRows += "<tr>" + "<th scope=\"row\">" + (i + 1) + "</th> " + "<td>" + newObject.get("name") + "</td>"
					+ "<td>" + newObject.get("gender") + "</td>" + "<td>" + newObject.get("category") + "</td>" + "<td>"
					+ newObject.get("message") + "</td>" + "</tr>";
		}

		hitCounter++;
		String hitCounterText = "<div class=\"row\"> <div class=\"col-md-6\"> <h3 class=\"text-danger\">Hit Counter/Visits: "
				+ hitCounter + "</h3> </div> </div>";
		String errorMessage = (String) request.getAttribute("errorMessage");
		if (errorMessage == null)
			errorMessage = "";
		String maleSelected = "";
		String femaleSelected = "";
		if (gender != null && gender.equals("Male"))
			maleSelected = "checked=\"checked\"";
		if (gender != null && gender.equals("Female"))
			femaleSelected = "checked=\"checked\"";

		String contactUsPage = "<!DOCTYPE html>\r\n" + "<html lang=\"en\">\r\n" + "\r\n" + "<head>\r\n"
				+ "<meta charset=\"UTF-8\">\r\n"
				+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\r\n"
				+ "<meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\r\n" + "<title>Contact Us Form</title>\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\"\r\n"
				+ "	integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\"\r\n"
				+ "	crossorigin=\"anonymous\">\r\n" + "<style>\r\n" + "#myheader {\r\n" + "	text-align: center;\r\n"
				+ "	font-size: 30px;\r\n" + "	text-decoration: underline;\r\n" + "	background-color: black;\r\n"
				+ "	color: white;\r\n" + "	border-radius: 10px;\r\n" + "	margin-top: 10px;\r\n"
				+ "	margin-bottom: 20px;\r\n" + "}\r\n" + "</style>\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n"
				+ "\r\n" + "	<nav class=\"navbar navbar-expand-lg navbar-dark bg-primary\">\r\n"
				+ "		<a class=\"navbar-brand\" href=\"#\">Lab10 - Introduction to Java\r\n"
				+ "			Servlet technology</a>\r\n"
				+ "		<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\"\r\n"
				+ "			data-target=\"#navbarColor02\" aria-controls=\"navbarColor02\"\r\n"
				+ "			aria-expanded=\"false\" aria-label=\"Toggle navigation\">\r\n"
				+ "			<span class=\"navbar-toggler-icon\"></span>\r\n" + "		</button>\r\n" + "\r\n"
				+ "		<div class=\"collapse navbar-collapse\" id=\"navbarColor02\">\r\n"
				+ "			<ul class=\"navbar-nav mr-auto\">\r\n"
				+ "				<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "					href=\"../../index.html\">| Homepage</a></li>\r\n" + "			</ul>\r\n"
				+ "			<form class=\"form-inline\" action=\"../../index.html\">\r\n" + "\r\n"
				+ "				<button class=\"btn btn-outline-light my-2 my-sm-0\" type=\"submit\">Sign\r\n"
				+ "					Out</button>\r\n" + "			</form>\r\n" + "		</div>\r\n" + "	</nav>\r\n"
				+ "\r\n" + "	<div class=\"container\">\r\n" + "		<header id=\"myheader\">\r\n"
				+ "			<label>Contuct US Form</label>\r\n" + "		</header>\r\n"
				+ "		<form method=\"POST\" action=\"DataProcessor\">\r\n" + "			<div>\r\n"
				+ "			<h5 style=\"color: red\">" + errorMessage + "</h5>\r\n" + "			</div>\r\n"
				+ "			<div class=\"row\">\r\n" + "				<div class=\"col-md-6\">\r\n"
				+ "					<div class=\"form-group\">\r\n"
				+ "						<label for=\"productname\">Name</label> <input type=\"text\"\r\n" + " value="
				+ '"' + name + '"' + " name=\"name\" class=\"form-control\" id=\"productname\"\r\n"
				+ "							placeholder=\"Name\">\r\n" + "					</div>\r\n"
				+ "				</div>\r\n" + "				<div class=\"col-md-6\">\r\n"
				+ "					<div class=\"form-group\">\r\n"
				+ "						<label for=\"supplier\">Category</label> <select name=\"category\"\r\n"
				+ "							class=\"form-control form-control-sm\" id=\"supplier\">\r\n"
				+ "							<option>" + category + "</option>\r\n"
				+ "							<option>Feedback</option>\r\n"
				+ "							<option>Inquiry</option>\r\n"
				+ "							<option>Complaint</option>\r\n" + "						</select>\r\n"
				+ "					</div>\r\n" + "				</div>\r\n" + "			</div>\r\n" + "\r\n"
				+ "			<div class=\"row\">\r\n" + "				<div class=\"col-md-6\">\r\n"
				+ "					<div class=\"form-group\">\r\n"
				+ "						<div class=\"custom-control custom-radio\">\r\n"
				+ "							<input type=\"radio\" class=\"custom-control-input\" id=\"radio1\"\r\n"
				+ "								name=\"gender\" value=\"Male\" " + maleSelected
				+ "> <label class=\"custom-control-label\"\r\n"
				+ "								for=\"radio1\">Male</label>\r\n" + "						</div>\r\n"
				+ "						<div class=\"custom-control custom-radio\">\r\n"
				+ "							<input type=\"radio\" class=\"custom-control-input\" id=\"radio2\"\r\n"
				+ "								name=\"gender\" value=\"Female\" " + femaleSelected
				+ "> <label class=\"custom-control-label\"\r\n"
				+ "								for=\"radio2\">Female</label>\r\n" + "						</div>\r\n"
				+ "					</div>\r\n" + "				</div>\r\n"
				+ "				<div class=\"col-md-6\">\r\n" + "					<div class=\"form-group\">\r\n"
				+ "						<label for=\"name\">Message</label>\r\n"
				+ "						<textarea class=\"form-control\" rows=\"3\" name=\"message\"\r\n"
				+ " placeholder=\"Message\">" + message + "</textarea>\r\n" + "					</div>\r\n"
				+ "				</div>\r\n" + "			</div>\r\n" + "\r\n" + "			<div class=\"row\">\r\n"
				+ "				<div class=\"col-md-6\">\r\n"
				+ "					<div class=\"form-group\"></div>\r\n" + "				</div>\r\n"
				+ "				<div class=\"col-md-6\">\r\n" + "					<div class=\"form-group\">\r\n"
				+ "						<button type=\"submit\" class=\"btn btn-outline-primary\">SUBMIT</button>\r\n"
				+ "						<button type=\"reset\" class=\"btn btn-outline-secondary\">Reset</button>\r\n"
				+ "						<button type=\"reset\" class=\"btn btn-outline-danger\">Cancel</button>\r\n"
				+ "					</div>\r\n" + "				</div>\r\n" + "			</div>\r\n" + "\r\n"

				+ "<div class=\"row\">\r\n" + "				<div class=\"col-md-12\">\r\n"
				+ "					<table class=\"table table-striped\">\r\n" + "						<thead>\r\n"
				+ "							<tr>\r\n" + "								<th>#</th>\r\n"
				+ "								<th>Name</th>\r\n" + "								<th>Gender</th>\r\n"
				+ "								<th>Category</th>\r\n"
				+ "								<th>Message</th>\r\n" + "							</tr>\r\n"
				+ "						</thead>\r\n" + "						<tbody>\r\n" +

				dataRows +

				"						</tbody>\r\n" + "					</table>\r\n" + "				</div>\r\n"
				+ "			</div>"

				+ hitCounterText + "		</form>\r\n" + "	</div>\r\n" + "</body>\r\n" + "\r\n" + "</html>";
		response.getWriter().append(contactUsPage);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
