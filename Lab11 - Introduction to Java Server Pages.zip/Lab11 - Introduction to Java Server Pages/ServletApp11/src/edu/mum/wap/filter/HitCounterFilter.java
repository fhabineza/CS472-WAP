package edu.mum.wap.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * Servlet Filter implementation class HitCounterFilter
 */
@WebFilter("/HitCounterFilter")
public class HitCounterFilter implements Filter {

	private Long hitCounter;

	/**
	 * Default constructor.
	 */
	public HitCounterFilter() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {

	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		hitCounter++;
		System.out.println("*************************************");
		System.out.println("One more hit, Count is: " + hitCounter);
		chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		hitCounter = Long.valueOf(0);
	}

}
