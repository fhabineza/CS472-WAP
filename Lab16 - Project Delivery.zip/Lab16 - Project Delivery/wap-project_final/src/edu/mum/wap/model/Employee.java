package edu.mum.wap.model;

public class Employee extends Person {

	private static final long serialVersionUID = 1L;

}
