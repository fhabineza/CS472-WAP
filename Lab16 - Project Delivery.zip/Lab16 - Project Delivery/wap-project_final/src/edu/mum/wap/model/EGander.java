package edu.mum.wap.model;

public enum EGander {
	MALE, FEMALE;
}
