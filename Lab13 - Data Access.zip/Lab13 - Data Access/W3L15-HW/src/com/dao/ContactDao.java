package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.model.CFormData;

public class ContactDao {

	private DataSource dtaSource;

	public ContactDao() {
		try {
			Context initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:comp/env");
			dtaSource = (DataSource) envContext.lookup("jdbc/contacts_db");

		} catch (NamingException e) {
			System.err.println(e);
		}

	}

	public String checkConnection() throws SQLException {
		Connection con = dtaSource.getConnection();
		if (con != null) {
			return "Connection establishe";
		} else {
			return "No Connection please try again";
		}
	}

	public CFormData saveData(CFormData cfData) {
		try {
			Connection con = dtaSource.getConnection();
			PreparedStatement psm = con.prepareStatement(
					"INSERT INTO contacts_db.contacts (name, gender, category, message) VALUES(?, ?, ?, ?)");
			psm.setString(1, cfData.getName());
			psm.setString(2, cfData.getGender());
			psm.setString(3, cfData.getCategory());
			psm.setString(4, cfData.getMessage());
			psm.executeUpdate();
		} catch (SQLException e) {
			System.err.println(e);
		}

		return cfData;

	}

	public List<CFormData> getData() {
		List<CFormData> dList = new ArrayList<CFormData>();

		try {
			Connection con = dtaSource.getConnection();
			PreparedStatement psm = con.prepareStatement(
					"SELECT (cId, name, gender, category, message FROM contacts_db.contacts ORDER BY name");
			ResultSet rSet = psm.executeQuery();
			while (rSet.next()) {
				int cId = rSet.getInt("cID");
				String name = rSet.getString("name");
				String gender = rSet.getString("gender");
				String category = rSet.getString("category");
				String message = rSet.getString("message");

				CFormData data = new CFormData(cId, name, gender, category, message);
				dList.add(data);
			}
		} catch (SQLException e) {
			System.err.println(e);
		}

		return dList;
	}

}
