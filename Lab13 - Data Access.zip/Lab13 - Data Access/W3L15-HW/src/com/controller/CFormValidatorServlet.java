package com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.ContactDao;
import com.model.CFormData;

/**
 * Servlet implementation class CFormValidator
 */
@WebServlet(name = "CFormValidatorServlet", urlPatterns = { "/cform-validator" }, description = "CFormValidatorServlet")
public class CFormValidatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ContactDao contactDao;
	
	

	public CFormValidatorServlet() {
		this.contactDao = new ContactDao();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String category = request.getParameter("category");
		String message = request.getParameter("message");

		List<String> errors = new ArrayList<String>();

		if (name == null || name.isEmpty()) {
			errors.add("Name is missing");
		}
		if (gender == null || gender.isEmpty()) {
			errors.add("Gender is missing");
		}
		if (category == null || category.equalsIgnoreCase("Select Category")) {
			errors.add("Category is missing");
		}
		if (message == null || message.isEmpty()) {
			errors.add("Message is missing");
		}

		if (!errors.isEmpty()) {
			// There are errors. Send the old HTML and for example add
			request.setAttribute("errors", errors);
			RequestDispatcher rd = request.getRequestDispatcher("/c-form");
			rd.forward(request, response);
		} else {

			// No errors! Send the new HTML.
			CFormData cData = new CFormData(name, gender, category, message);
			CFormData saveCFormData = contactDao.saveData(cData);
			request.setAttribute("saveCFormData", saveCFormData);
			
			RequestDispatcher rd = request.getRequestDispatcher("/thank-you");
			rd.forward(request, response);

		}
	}

}
